#!/usr/bin/env node
//Device ID: nodeROS
//Device key: hMwIyNAn6xgh8kuak02RYJm0oBpUrkI0CWGYvr9btik=

'use strict';

const rosnodejs = require('rosnodejs');
const std_msgs = rosnodejs.require('std_msgs').msg;

var clientFromConnectionString = require('azure-iot-device-mqtt').clientFromConnectionString;
var Message = require('azure-iot-device').Message;

//var connectionString = 'HostName=usando-iot-demo.azure-devices.net;SharedAccessKeyName=iothubowner;SharedAccessKey=a5m1yMB9A77Aiw+43c/qiBzI6S2ysvObRrFqCePwKp4=';
//var connectionString = 'HostName=usando-iot-demo.azure-devices.net;DeviceId=odroid;SharedAccessKey=d/J3fDJ2ZFRid7Ny3dmRSPCEyWRqdpOpCx/zvmlYMMI=';
//var connectionString = 'HostName=testCount.azure-devices.net;SharedAccessKeyName=iothubowner;SharedAccessKey=QJkjwPuXtVvi9bp5FHzNjWx+IDCUg9o9BQV7SsRdhK0=';
//var connectionString = 'HostName=testCount.azure-devices.net;DeviceId=nodeROS;SharedAccessKey=QJkjwPuXtVvi9bp5FHzNjWx+IDCUg9o9BQV7SsRdhK0=';
//var connectionString = 'HostName=testCount.azure-devices.net;DeviceId=nodeROS;SharedAccessKey=QJkjwPuXtVvi9bp5FHzNjWx+IDCUg9o9BQV7SsRdhK0='
var connectionString = 'HostName=testCount.azure-devices.net;DeviceId=nodeROS;SharedAccessKey=hMwIyNAn6xgh8kuak02RYJm0oBpUrkI0CWGYvr9btik='

var client = clientFromConnectionString(connectionString);


function printResultFor(op) {
  return function printResult(err, res) {
    if (err) console.log(op + ' error: ' + err.toString());
    if (res) console.log(op + ' status: ' + res.constructor.name);
  };
}

var connectCallback = function (err) {
  if (err) {
    console.log('Could not connect: ' + err);
  } else {
    console.log('Client connected');

    // Create a message and send it to the IoT Hub every second
    var listener = function() {
      // Register node with ROS master
      rosnodejs.initNode('/listener_nodejs')
        .then((rosNode) => {
          // Create ROS subscriber on the 'chatter' topic expecting String messages
          let sub = rosNode.subscribe('counter_people', std_msgs.String,
            (data) => { // define callback execution
              //rosnodejs.log.info('I heard: [' + JSON.parse(data.data) + ']');
              console.log(JSON.parse(data.data)["data_salida"])
              console.log(JSON.parse(data.data)["data_entrada"])
              console.log(' ')

              var datax = JSON.stringify({
                deviceId: 'kinetic_lubuntu',
                timestamp: Date.now(),
                entrada:JSON.parse(data.data)["data_salida"],
                salida:JSON.parse(data.data)["data_entrada"],
              });

              var message = new Message(datax);
              //message.properties.add('temperatureAlert', (temperature > 30) ? 'true' : 'false');
              console.log("Sending message: " + message.getData());
              client.sendEvent(message, printResultFor('send'));
            }
          );
        });
    }
    if (require.main === module) {
      listener();
    }
  }
};

client.open(connectCallback);




/////////////////
