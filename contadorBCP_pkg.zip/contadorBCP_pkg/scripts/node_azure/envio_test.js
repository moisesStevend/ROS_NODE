//'use strict';

var clientFromConnectionString = require('azure-iot-device-mqtt').clientFromConnectionString;
var Message = require('azure-iot-device').Message;

//var connectionString = 'HostName=usando-iot-demo.azure-devices.net;SharedAccessKeyName=iothubowner;SharedAccessKey=a5m1yMB9A77Aiw+43c/qiBzI6S2ysvObRrFqCePwKp4=';
//var connectionString = 'HostName=usando-iot-demo.azure-devices.net;DeviceId=odroid;SharedAccessKey=d/J3fDJ2ZFRid7Ny3dmRSPCEyWRqdpOpCx/zvmlYMMI=';
//var connectionString = 'HostName=testCount.azure-devices.net;SharedAccessKeyName=iothubowner;SharedAccessKey=QJkjwPuXtVvi9bp5FHzNjWx+IDCUg9o9BQV7SsRdhK0=';
//var connectionString = 'HostName=testCount.azure-devices.net;DeviceId=nodeROS;SharedAccessKey=QJkjwPuXtVvi9bp5FHzNjWx+IDCUg9o9BQV7SsRdhK0=';
var connectionString = 'HostName=testCount.azure-devices.net;DeviceId=nodeROS;SharedAccessKey=hMwIyNAn6xgh8kuak02RYJm0oBpUrkI0CWGYvr9btik='

var client = clientFromConnectionString(connectionString);


function printResultFor(op) {
  return function printResult(err, res) {
    if (err) console.log(op + ' error: ' + err.toString());
    if (res) console.log(op + ' status: ' + res.constructor.name);
  };
}

var connectCallback = function (err) {
  if (err) {
    console.log('Could not connect: ' + err);
  } else {
    console.log('Client connected');

    // Create a message and send it to the IoT Hub every second
    var listener = function() {
      setInterval(function(){
            var directions = [1,-1]

            var data = JSON.stringify({
              deviceId: 'odroid',
              timestamp: Date.now(),
              direction: parseInt(datox['dd']),//directions[Math.floor(Math.random()*directions.length)],
              people: parseInt(datox['cuenta']),
            });


            var message = new Message(data);
            //message.properties.add('temperatureAlert', (temperature > 30) ? 'true' : 'false');
            console.log("Sending message: " + message.getData());
            client.sendEvent(message, printResultFor('send'));
        }, 1000);
    }
  }
};

client.open(connectCallback);




/////////////////
